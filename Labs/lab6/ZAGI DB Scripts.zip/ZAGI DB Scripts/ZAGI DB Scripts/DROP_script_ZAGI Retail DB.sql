DROP TABLE SoldVia;
DROP TABLE SalesTransaction;
DROP TABLE Store;
DROP TABLE Product;
DROP TABLE Vendor;
DROP TABLE Region;
DROP TABLE Category;
DROP TABLE Customer; 