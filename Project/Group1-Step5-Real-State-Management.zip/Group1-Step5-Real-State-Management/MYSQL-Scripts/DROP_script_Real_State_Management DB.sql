-- 
-- Group 1
-- Members: Mahdis Rezaei Tamijani, MySQL Expert
--          Gurjyot Singh Bajwa, MS SQL Expert
-- --------------------------------------

USE G1_Real_State_Management_DB;



DROP TABLE Bank_ParticipatesIn_PurchaseContract;
DROP TABLE Seller_ParticipatesIn_PurchaseContract;
DROP TABLE Buyer_ParticipatesIn_PurchaseContract;
DROP TABLE Buyer_Realtor_ParticipationIn_PurchaseContract;
DROP TABLE Seller_Realtor_ParticipationIn_PurchaseContract;
DROP TABLE Purchase_Contract;
DROP TABLE Realtor_WorksFor_Realty_Company;
DROP TABLE Renter_Dependent;
DROP TABLE Properties_beingRented_by_RentalContract;
DROP TABLE Rental_Contract;
DROP TABLE Properties_Photos;
DROP TABLE People;
DROP TABLE BANKS;
DROP TABLE Seller;
DROP TABLE Buyer;
DROP TABLE Renter;
DROP TABLE Realtor;
DROP TABLE Realty_Company;
DROP TABLE Agriculture;
DROP TABLE Parking;
DROP TABLE DetachedHouse;
DROP TABLE Land;
DROP TABLE Condo;
DROP TABLE Recreation;
DROP TABLE Properties;
