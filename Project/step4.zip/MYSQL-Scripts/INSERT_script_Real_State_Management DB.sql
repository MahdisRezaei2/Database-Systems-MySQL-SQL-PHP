 
 -- These insert statements have added to MSSQL and run fine
 -- Inserting values into the People table
INSERT INTO People (Person_ID, Occupation, Phone_Number, First_Name, Last_Name, Street, Apartment_Number, Province, City)
VALUES (1, 'Seller', '123456789', 'Mahdis', 'Rezaei', 'Main Street', 2004, 'BC', 'Vancouver');
INSERT INTO People (Person_ID, Occupation, Phone_Number, First_Name, Last_Name, Street, Apartment_Number, Province, City)
VALUES (2, 'Buyer', '123456669', 'Ricardo', 'Smith', 'Burrard Street', 2006, 'BC', 'Vancouver');
INSERT INTO People (Person_ID, Occupation, Phone_Number, First_Name, Last_Name, Street, Apartment_Number, Province, City)
VALUES (3, 'Renter', '123444444', 'Allen', 'Smith', 'some Street', 1006, 'BC', 'Vancouver');

-- Inserting values into the Banks table
INSERT INTO Banks (Bank_ID, Bank_Name, Amount_of_Mortgage)
VALUES (5, 'RBC Bank', 1000000.00);
-- Inserting values into the Purchase_Contract table
INSERT INTO Purchase_Contract (Purchase_Contract_ID)
VALUES (12);

-- Inserting values into the Bank_ParticipatesIn_PurchaseContract table
INSERT INTO Bank_ParticipatesIn_PurchaseContract (Bank_ID, Purchase_Contract_ID)
VALUES (5, 12);

-- Inserting values into the Seller table
INSERT INTO Seller (SellerID)
VALUES (1);

-- Inserting values into the Seller_ParticipatesIn_PurchaseContract table
INSERT INTO Seller_ParticipatesIn_PurchaseContract (Purchase_Contract_ID, SellerID)
VALUES (12, 1);

-- Inserting values into the Buyer table
INSERT INTO Buyer (BuyerID)
VALUES (2);

-- Inserting values into the Buyer_ParticipatesIn_PurchaseContract table
INSERT INTO Buyer_ParticipatesIn_PurchaseContract (Purchase_Contract_ID, BuyerID)
VALUES (12, 2);

-- Inserting values into the Renter table
INSERT INTO Renter (RenterID)
VALUES (3);

-- Inserting values into the Renter_Dependent table
INSERT INTO Renter_Dependent (RenterID, DependentID)
VALUES (3, 13);

-- Inserting values into the Rental_Contract table
INSERT INTO Rental_Contract (Rental_Contract_ID, MonthlyRent, End_Date_Rent, Start_Date_Rent, RenterID)
VALUES (16, 1500.00, '2023-07-01', '2023-08-01', 3);

-- Inserting values into the Realtor table
INSERT INTO Realtor (RealtorID, PhoneNumber, FirstName, LastName, LicenseNumber, Years_of_Experience, Email_Address, App_Number, City, Street, PostalCode, Province)
VALUES (14, '987654321', 'Jane', 'Smith', '123456', 5, 'jane@example.com', 'APP123', 'New York', 'Broadway', '12345', 'NY');

-- Inserting values into the Buyer_Realtor_ParticipationIn_PurchaseContract table
INSERT INTO Buyer_Realtor_ParticipationIn_PurchaseContract (Purchase_Contract_ID, RealtorID)
VALUES (12, 14);

-- Inserting values into the Seller_Realtor_ParticipationIn_PurchaseContract table
INSERT INTO Seller_Realtor_ParticipationIn_PurchaseContract (Purchase_Contract_ID, RealtorID)
VALUES (12, 14);

-- Inserting values into the Properties table
INSERT INTO Properties (PropertyID, ListedSince, Ownership, Price, Description, City, Street, App_Number, PostalCode, Province)
VALUES (17, '2023-06-01', 'Single Ownership', 500000.00, 'Beautiful house with a garden', 'Vancouver', 'londsdale street', 'Apt 1', '90001', 'CA');

-- Inserting values into the Properties_beingRented_by_RentalContract table
INSERT INTO Properties_beingRented_by_RentalContract (Rental_Contract_ID, PropertyID)
VALUES (16, 17);
